import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var manager: DownloadManager

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.055, blue: 0.09).ignoresSafeArea()
                VStack(spacing: 18) {
                    header
                    HStack {
                        TextField("ألصق رابط الملف أو الفيديو أو الصوت", text: $manager.urlText)
                            .textInputAutocapitalization(.never)
                            .keyboardType(.URL)
                            .autocorrectionDisabled()
                            .padding(14)
                            .background(Color.white.opacity(0.09))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.white)
                        Button(action: manager.addFromText) {
                            Image(systemName: "arrow.down")
                                .font(.title3.bold())
                                .foregroundStyle(.black)
                                .frame(width: 48, height: 48)
                                .background(Color.cyan)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                    HStack {
                        Text("التنزيلات").font(.headline).foregroundStyle(.white)
                        Spacer()
                        Text("\(manager.items.count) عناصر").font(.caption).foregroundStyle(.gray)
                    }
                    if manager.items.isEmpty {
                        Spacer()
                        Image(systemName: "arrow.down.to.line.circle")
                            .font(.system(size: 58)).foregroundStyle(.cyan)
                        Text("لا توجد تنزيلات بعد").foregroundStyle(.white)
                        Text("انسخ رابطاً مباشراً أو شاركه من Safari").font(.caption).foregroundStyle(.gray)
                        Spacer()
                    } else {
                        List {
                            ForEach(manager.items) { item in
                                HStack(spacing: 12) {
                                    Image(systemName: icon(for: item.fileName))
                                        .font(.title2).foregroundStyle(.cyan).frame(width: 34)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(item.fileName).lineLimit(1).foregroundStyle(.white)
                                        Text(item.status).font(.caption).foregroundStyle(.gray)
                                    }
                                    Spacer()
                                    if item.status == "اكتمل" {
                                        Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                                    } else {
                                        ProgressView().tint(.cyan)
                                    }
                                }
                                .listRowBackground(Color.white.opacity(0.06))
                            }
                        }
                        .scrollContentBackground(.hidden)
                    }
                    Text("يدعم الروابط المباشرة المسموح بتنزيلها فقط")
                        .font(.caption2).foregroundStyle(.gray)
                }
                .padding()
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
        .onAppear { manager.importSharedQueue() }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "arrow.down.circle.fill")
                .font(.system(size: 36)).foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: 3) {
                Text("Media Downloader").font(.title2.bold()).foregroundStyle(.white)
                Text("مدير التنزيلات").font(.caption).foregroundStyle(.gray)
            }
            Spacer()
        }
        .padding(.vertical, 12)
    }

    private func icon(for name: String) -> String {
        let ext = URL(fileURLWithPath: name).pathExtension.lowercased()
        if ["mp4", "mov", "m4v", "mkv"].contains(ext) { return "video.fill" }
        if ["mp3", "m4a", "wav", "aac"].contains(ext) { return "waveform" }
        if ext == "pdf" { return "doc.richtext" }
        if ["jpg", "jpeg", "png", "gif", "webp"].contains(ext) { return "photo" }
        return "doc.fill"
    }
}

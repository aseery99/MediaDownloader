import Foundation
import SwiftUI

struct DownloadItem: Identifiable {
    let id = UUID()
    let url: URL
    var fileName: String
    var progress: Double = 0
    var status: String = "في الانتظار"
    var localURL: URL?
}

@MainActor
final class DownloadManager: ObservableObject {
    @Published var items: [DownloadItem] = []
    @Published var urlText = ""

    private let groupID = "group.com.aseery99.MediaDownloader"
    private let queueKey = "pendingDownloadURLs"

    init() { importSharedQueue() }

    func addFromText() {
        guard let url = URL(string: urlText.trimmingCharacters(in: .whitespacesAndNewlines)),
              let scheme = url.scheme?.lowercased(),
              ["https", "http"].contains(scheme) else { return }
        enqueue(url)
        urlText = ""
    }

    func importSharedQueue() {
        guard let defaults = UserDefaults(suiteName: groupID) else { return }
        let queued = defaults.stringArray(forKey: queueKey) ?? []
        defaults.removeObject(forKey: queueKey)
        queued.compactMap(URL.init(string:)).forEach(enqueue)
    }

    func enqueue(_ url: URL) {
        guard !items.contains(where: { $0.url == url }) else { return }
        items.insert(DownloadItem(url: url,
                                  fileName: url.lastPathComponent.isEmpty ? "download" : url.lastPathComponent), at: 0)
        let id = items[0].id
        Task { await download(id: id, from: url) }
    }

    private func download(id: UUID, from url: URL) async {
        guard let index = items.firstIndex(where: { $0.id == id }) else { return }
        items[index].status = "جارٍ التنزيل"
        do {
            let (temporaryURL, response) = try await URLSession.shared.download(from: url)
            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode) else {
                throw URLError(.badServerResponse)
            }
            let suggested = response.suggestedFilename ?? url.lastPathComponent
            let rawName = suggested.isEmpty ? "download-\(UUID().uuidString)" : suggested
            let safeName = URL(fileURLWithPath: rawName).lastPathComponent
            let destination = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent(safeName)
            let finalURL = uniqueURL(for: destination)
            try FileManager.default.moveItem(at: temporaryURL, to: finalURL)
            if let i = items.firstIndex(where: { $0.id == id }) {
                items[i].fileName = finalURL.lastPathComponent
                items[i].localURL = finalURL
                items[i].progress = 1
                items[i].status = "اكتمل"
            }
        } catch {
            if let i = items.firstIndex(where: { $0.id == id }) {
                items[i].status = "تعذّر التنزيل: \(error.localizedDescription)"
            }
        }
    }

    private func uniqueURL(for url: URL) -> URL {
        guard FileManager.default.fileExists(atPath: url.path) else { return url }
        let base = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        return url.deletingLastPathComponent()
            .appendingPathComponent("\(base)-\(UUID().uuidString.prefix(6)).\(ext)")
    }
}

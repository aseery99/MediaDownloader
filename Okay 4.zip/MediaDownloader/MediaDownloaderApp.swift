import SwiftUI

@main
struct MediaDownloaderApp: App {
    @StateObject private var manager = DownloadManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(manager)
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

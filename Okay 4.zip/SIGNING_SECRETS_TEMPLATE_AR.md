# إعداد أسرار التوقيع لاحقاً (لا ترفع الأسرار إلى Git)

بعد تفعيل عضوية Apple Developer المدفوعة، استخدم مستودع GitHub ثم أضف القيم التالية من Settings → Secrets and variables → Actions. لا تضع القيم في ملفات المشروع أو Issues أو المحادثات.

| اسم السر | المحتوى |
|---|---|
| `APPLE_TEAM_ID` | Team ID من حساب Apple Developer |
| `IOS_DIST_CERTIFICATE_P12_BASE64` | شهادة Apple Distribution بصيغة P12 بعد تحويلها إلى Base64 |
| `IOS_DIST_CERTIFICATE_PASSWORD` | كلمة مرور ملف P12 |
| `IOS_APP_ADHOC_PROFILE_BASE64` | ملف Ad Hoc Provisioning Profile للتطبيق الرئيسي، Base64 |
| `IOS_EXTENSION_ADHOC_PROFILE_BASE64` | ملف Ad Hoc Provisioning Profile لامتداد المشاركة، Base64 |

## معرفات التطبيق الحالية
- التطبيق: `com.aseery99.MediaDownloader`
- امتداد المشاركة: `com.aseery99.MediaDownloader.ShareExtension`
- App Group: `group.com.aseery99.MediaDownloader`

يجب تسجيل App ID صريح لكل Bundle ID وتفعيل App Groups وربط المجموعة أعلاه بكلا المعرفين. أضف UDID الخاص بالـ iPhone إلى حساب المطور قبل إنشاء ملفي Ad Hoc.

## تشغيل البناء
من GitHub → Actions → Media Downloader iOS CI → Run workflow، اختر `ad-hoc`. اختيار `simulator` ينتج تطبيق محاكي غير قابل للتثبيت على iPhone. اختيار `ad-hoc` يتطلب الأسرار الخمسة أعلاه وينتج IPA موقّعاً إذا كانت الشهادة والملفات صالحة ومتطابقة.

**الأمان:** لا تشارك P12 أو كلمة مروره أو أي مفاتيح خاصة. خزّنها فقط في GitHub Actions Secrets أو مدير أسرار موثوق.

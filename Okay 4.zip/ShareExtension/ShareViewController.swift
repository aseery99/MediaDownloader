import UIKit
import Social
import UniformTypeIdentifiers

final class ShareViewController: UIViewController {
    private let groupID = "group.com.aseery99.MediaDownloader"
    private let queueKey = "pendingDownloadURLs"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        let label = UILabel()
        label.text = "تم استلام الرابط. اضغط إضافة لإرساله إلى Media Downloader."
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false

        let button = UIButton(type: .system)
        button.setTitle("إضافة إلى التنزيلات", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 17)
        button.addTarget(self, action: #selector(saveAndClose), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(label)
        view.addSubview(button)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -25),
            button.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 24),
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    @objc private func saveAndClose() {
        guard let extensionItem = extensionContext?.inputItems.first as? NSExtensionItem,
              let providers = extensionItem.attachments else { finish(); return }

        let group = DispatchGroup()
        var foundURLs: [String] = []
        for provider in providers where provider.hasItemConformingToTypeIdentifier(UTType.url.identifier) {
            group.enter()
            provider.loadItem(forTypeIdentifier: UTType.url.identifier, options: nil) { item, _ in
                if let url = item as? URL, ["http", "https"].contains(url.scheme?.lowercased() ?? "") {
                    foundURLs.append(url.absoluteString)
                }
                group.leave()
            }
        }
        group.notify(queue: .main) {
            if let defaults = UserDefaults(suiteName: self.groupID) {
                let old = defaults.stringArray(forKey: self.queueKey) ?? []
                defaults.set(old + foundURLs, forKey: self.queueKey)
            }
            self.finish()
        }
    }

    private func finish() {
        extensionContext?.completeRequest(returningItems: [], completionHandler: nil)
    }
}
